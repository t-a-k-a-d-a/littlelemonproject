/api/bookings/
/api/registration/